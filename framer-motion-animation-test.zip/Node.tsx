import React, { ReactElement, useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { NodeType } from "./pages/index";

interface Props extends NodeType {
  // x: number;
  // y: number;
  // r: number;
  // w: number;
  moveNodes: () => void;
}

export default function Node({
  x,
  y,
  r,
  strokeWidth,
  moveNodes,
}: Props): ReactElement {
  const cx = useMotionValue(x);
  const sx = useSpring(cx);
  const cy = useMotionValue(y);
  const sy = useSpring(cy);
  const cr = useMotionValue(r);
  const sr = useSpring(r);
  const width = useMotionValue(strokeWidth);
  const sWidth = useSpring(width);

  useEffect(() => {
    cx.set(x);
    cy.set(y);
    cr.set(r);
    width.set(strokeWidth);
  }, [cr, cy, cx, width, strokeWidth, x, y, r]);

  console.log("rendering");
  return (
    <motion.circle
      onClick={() => {
        moveNodes();
      }}
      fill="teal"
      cx={sx}
      cy={sy}
      r={sr}
      strokeWidth={sWidth}
      stroke="red"
      transition={{
        duration: 1.8,
      }}
    />
  );
}
